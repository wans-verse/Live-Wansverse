# Build lewat GitHub (tanpa install Flutter)

1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk .github).
2. Repo > Settings > Secrets and variables > Actions > New repository secret:
   - ZEGO_APP_ID   (angka dari console.zegocloud.com)
   - ZEGO_APP_SIGN (string AppSign)
3. Tab Actions > Build APK > Run workflow.
4. Setelah hijau, buka run-nya, download artifact "livekita-apk", ekstrak, install app-release.apk di HP.
